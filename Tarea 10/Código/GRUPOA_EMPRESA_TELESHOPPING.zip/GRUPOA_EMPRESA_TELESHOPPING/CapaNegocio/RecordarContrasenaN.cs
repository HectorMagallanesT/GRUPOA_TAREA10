﻿
using CapaDatos;

namespace CapaNegocio
{
    public class RecordarContrasenaN
    {
        // Declarar una instancia de la clase RecordarContrasenaD
        private RecordarContrasenaD datos;


        /// <summary>
        /// Constructor de la clase RecordarContrasenaN.
        /// Crea una nueva instancia de la clase RecordarContrasenaN y 
        /// inicializa la instancia de datos asociándola a una nueva instancia de RecordarContrasenaD.
        /// </summary>
        public RecordarContrasenaN()
        {
            // Crear una nueva instancia de la clase RecordarContrasenaD
            datos = new RecordarContrasenaD();
        }


        /// <summary>
        /// Busca la contraseña asociada a un CI específico.
        /// </summary>
        /// <param name="ci">Cédula de identidad del usuario.</param>
        /// <returns>Contraseña asociada al CI, o null si no se encuentra.</returns>
        public string BuscarContrasena(string ci)
        {
            // Llamar al método BuscarContrasena de la instancia de la clase 
            return datos.BuscarContrasena(ci);
        }
    }
}
