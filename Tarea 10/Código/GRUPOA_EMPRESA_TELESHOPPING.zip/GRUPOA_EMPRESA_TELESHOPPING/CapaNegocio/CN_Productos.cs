﻿using System;
using System.Collections.Generic;
using System.Data;
using CapaDatos;

namespace CapaNegocio
{
    /// <summary>
    /// Clase de lógica de negocio para gestionar productos.
    /// </summary>
    public class CN_Productos
    {
        private CD_Productos manejadorProductos = new CD_Productos();

        /// <summary>
        /// Obtiene una lista de productos.
        /// </summary>
        /// <returns>Un DataTable que contiene la lista de productos.</returns>
        public DataTable GetListaProductos()
        {
            return manejadorProductos.getProductos();
        }

        /// <summary>
        /// Inserta un nuevo producto en la base de datos.
        /// </summary>
        /// <param name="foto">Imagen del producto.</param>
        /// <param name="nombre">Nombre del producto.</param>
        /// <param name="descripcion">Descripción del producto.</param>
        /// <param name="precio">Precio del producto.</param>
        /// <returns>True si la inserción fue exitosa; de lo contrario, false.</returns>
        public bool InsertarProducto(byte[] foto, string nombre, string descripcion, decimal precio)
        {
            return manejadorProductos.InsertarProducto(foto, nombre, descripcion, precio);
        }

        /// <summary>
        /// Busca productos por su nombre.
        /// </summary>
        /// <param name="nombreProducto">Nombre del producto a buscar.</param>
        /// <returns>Un DataTable que contiene los productos encontrados.</returns>
        public DataTable BuscarProductosPorNombre(string nombreProducto)
        {
            try
            {
                return manejadorProductos.BuscarProductosPorNombre(nombreProducto);
            }
            catch (Exception ex)
            {
                // Manejar excepciones aquí si es necesario
                return new DataTable(); // Devuelve un DataTable vacío en caso de error
            }
        }

        /// <summary>
        /// Elimina un producto de la base de datos.
        /// </summary>
        /// <param name="productoID">ID del producto a eliminar.</param>
        /// <returns>True si la eliminación fue exitosa; de lo contrario, false.</returns>
        public bool EliminarProducto(int productoID)
        {
            return manejadorProductos.EliminarProducto(productoID);
        }

        /// <summary>
        /// Modifica un producto en la base de datos.
        /// </summary>
        /// <param name="productoID">ID del producto a modificar.</param>
        /// <param name="foto">Imagen del producto.</param>
        /// <param name="nombre">Nuevo nombre del producto.</param>
        /// <param name="descripcion">Nueva descripción del producto.</param>
        /// <param name="precio">Nuevo precio del producto.</param>
        /// <returns>True si la modificación fue exitosa; de lo contrario, false.</returns>
        public bool ModificarProducto(int productoID, byte[] foto, string nombre, string descripcion, decimal precio)
        {
            return manejadorProductos.ModificarProducto(productoID, foto, nombre, descripcion, precio);
        }

        /// <summary>
        /// Agrega un producto al carrito de compras de un usuario.
        /// </summary>
        /// <param name="usuarioID">ID del usuario.</param>
        /// <param name="productoID">ID del producto a agregar al carrito.</param>
        /// <param name="cantidad">Cantidad de productos a agregar al carrito.</param>
        /// <param name="descripcion">Descripción del producto en el carrito.</param>
        /// <param name="precio">Precio del producto en el carrito.</param>
        public void AgregarProductoAlCarrito(string usuarioID, int productoID, int cantidad, string descripcion, decimal precio)
        {
            manejadorProductos.InsertarProductoEnCarrito(usuarioID, productoID, cantidad, descripcion, precio);
        }

        /// <summary>
        /// Obtiene el carrito de compras agrupado de un usuario.
        /// </summary>
        /// <param name="nombreUsuario">Nombre del usuario.</param>
        /// <returns>Un DataTable que contiene el carrito de compras agrupado del usuario.</returns>
        public DataTable ObtenerCarritoComprasAgrupado(string nombreUsuario)
        {
            return manejadorProductos.ObtenerCarritoComprasAgrupado(nombreUsuario);
        }
    }
}
