﻿
using CapaDatos;

namespace CapaNegocio
{
    public class LoginUsuarioN
    {
        // Instancia de la clase de la capa de datos para interactuar con la base de datos
        private LoginUsuarioD loginUsuarioD;

        /// <summary>
        /// Constructor de la clase LoginUsuarioN.
        /// </summary>
        /// <param name="connectionString">Cadena de conexión a la base de datos.</param>
        public LoginUsuarioN(string connectionString)
        {
            // Crea una instancia de la clase de la capa de datos con la cadena de conexión proporcionada
            loginUsuarioD = new LoginUsuarioD(connectionString);
        }


        /// <summary>
        /// Verifica si un usuario con el CI y contraseña especificados existe en la base de datos.
        /// </summary>
        /// <param name="ci">Número de cédula de identidad del usuario.</param>
        /// <param name="contrasena">Contraseña del usuario.</param>
        /// <returns>True si el usuario existe y la contraseña es correcta, False en caso contrario.</returns>
        public bool VerificarUsuario(string ci, string contrasena)
        {
            // Llama al método de la capa de datos para verificar si el usuario existe y la contraseña es correcta
            return loginUsuarioD.VerificarUsuario(ci, contrasena);
        }

        /// <summary>
        /// Verifica si un usuario con el CI especificado existe en la base de datos.
        /// </summary>
        /// <param name="ci">Número de cédula de identidad del usuario.</param>
        /// <returns>True si el usuario existe, False en caso contrario.</returns>
        public bool ExisteUsuario(string ci)
        {
            // Llama al método de la capa de datos para verificar si el usuario existe
            return loginUsuarioD.ExisteUsuario(ci);
        }



        /// <summary>
        /// Crea un nuevo usuario en la base de datos con la información proporcionada.
        /// </summary>
        /// <param name="nombreYApellido">Nombre y apellido del usuario.</param>
        /// <param name="ci">Número de cédula de identidad del usuario.</param>
        /// <param name="email">Correo del usuario.</param>
        /// <param name="contrasena">Contraseña del usuario.</param>
        /// <param name="confirmarContrasena">Confirmación de la contraseña del usuario.</param>
        public bool CrearUsuario(string nombreYApellido, string ci, string email, string contrasena, string confirmarContrasena)
        {
            // Llama al método de la capa de datos para crear un nuevo usuario en la base de datos
          //  loginUsuarioD.CrearUsuario(nombreYApellido, ci, email, contrasena, confirmarContrasena);

            return loginUsuarioD.CrearUsuario(nombreYApellido, ci, email, contrasena, confirmarContrasena);

        }
    }
}
