﻿
using System;
using System.Data;
using System.Data.SqlClient;


namespace CapaDatos
{
    public class LoginUsuarioD
    {
        // Cadena de conexión a la base de datos
        private string connectionString;


        /// <summary>
        /// Constructor de la clase LoginUsuarioD.
        /// </summary>
        /// <param name="connectionString">Cadena de conexión a la base de datos.</param>
        public LoginUsuarioD(string connectionString)
        {
            this.connectionString = connectionString; // Asigna la cadena de conexión proporcionada al campo de la clase
        }


        /// <summary>
        /// Verifica si el usuario existe en la base de datos.
        /// </summary>
        /// <param name="ci">Cédula de identidad del usuario a verificar.</param>
        /// <param name="contrasena">Contraseña del usuario a verificar.</param>
        /// <returns>True si el usuario existe y la contraseña es correcta, False en caso contrario.</returns>
        public bool VerificarUsuario(string ci, string contrasena)
        {
            string query = "VerificarUsuario";

            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                // Abre la conexión a la base de datos
                connection.Open();

                using (SqlCommand command = new SqlCommand(query, connection))
                {
                    // Agrega los parámetros a la consulta SQL para prevenir inyección de SQL
                    command.CommandType = CommandType.StoredProcedure;
                    command.Parameters.AddWithValue("@ci", ci);
                    command.Parameters.AddWithValue("@contrasena", contrasena);

                    // Ejecuta la consulta para obtener el número de registros que coinciden
                    // con el CI y la contraseña ingresados
                    int? count = (int?)command.ExecuteScalar();

                    // Devuelve True si se encontró al menos un registro coincidente,
                    // de lo contrario, devuelve False
                    return count > 0;
                }
            }
        }



        /// <summary>
        /// Verifica si el usuario ya existe en la base de datos.
        /// </summary>
        /// <param name="ci">Cédula de identidad del usuario a verificar.</param>
        /// <returns>True si el usuario existe, False en caso contrario.</returns>
        public bool ExisteUsuario(string ci)
        {
            string query = "ExisteUsuario";

            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                // Abre la conexión a la base de datos
                connection.Open();

                using (SqlCommand command = new SqlCommand(query, connection))
                {
                    // Agrega los parámetros a la consulta SQL para prevenir inyección de SQL
                    command.CommandType = CommandType.StoredProcedure;
                    command.Parameters.AddWithValue("@ci", ci);

                    // Ejecuta la consulta para obtener el número de registros que coinciden
                    // con el CI y la contraseña ingresados
                    int? a = (int?)command.ExecuteScalar();

                    // Devuelve True si se encontró al menos un registro coincidente,
                    // de lo contrario, devuelve False
                    return a > 0;
                }
            }
        }


        /// <summary>
        /// Crea un nuevo usuario en la base de datos.
        /// </summary>
        /// <param name="nombreYApellido">Nombre y apellido del usuario a crear.</param>
        /// <param name="ci">Cédula de identidad del usuario a crear.</param>
        /// <param name="email">Correo del usuario a crear.</param>
        /// <param name="contrasena">Contraseña del usuario a crear.</param>
        /// <param name="confirmarContrasena">Confirmación de la contraseña del usuario a crear.</param>
        public bool CrearUsuario(string nombreYApellido, string ci, string email, string contrasena, string confirmarContrasena)
        {
            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                // Abre la conexión a la base de datos
                connection.Open();

                string query = "CrearUsuario";
                using (SqlCommand command = new SqlCommand(query, connection))
                {
                    // Agrega los parámetros a la consulta SQL para prevenir inyección de SQL
                    command.CommandType = CommandType.StoredProcedure;
                    command.Parameters.AddWithValue("@nombreYApellido", nombreYApellido);
                    command.Parameters.AddWithValue("@ci", ci);
                    command.Parameters.AddWithValue("@email", email);
                    command.Parameters.AddWithValue("@contrasena", contrasena);
                    command.Parameters.AddWithValue("@confirmarContrasena", confirmarContrasena);
                  //  command.ExecuteNonQuery();

                    // Ejecuta la consulta y verifica si se creó el usuario exitosamente
                  int rowsAffected = command.ExecuteNonQuery();
                  return rowsAffected > 0; // Si se afectó al menos una fila, se considera exitoso

                }
            }
        }
    }
}
