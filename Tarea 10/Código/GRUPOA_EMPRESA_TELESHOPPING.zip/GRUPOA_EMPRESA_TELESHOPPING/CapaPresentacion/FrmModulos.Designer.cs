﻿namespace CapaPresentacion
{
    partial class FrmModulos
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.menuStrip1 = new System.Windows.Forms.MenuStrip();
            this.consultaDeCToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.catalogoDeProductosToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.gestiónDeComprasToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.pToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.ordenDeCompraGeneradaToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.labelNombreYApellido = new System.Windows.Forms.Label();
            this.logisticaDeEntregaToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.enviosToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.menuStrip1.SuspendLayout();
            this.SuspendLayout();
            // 
            // menuStrip1
            // 
            this.menuStrip1.BackColor = System.Drawing.SystemColors.ButtonShadow;
            this.menuStrip1.ImageScalingSize = new System.Drawing.Size(20, 20);
            this.menuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.consultaDeCToolStripMenuItem,
            this.gestiónDeComprasToolStripMenuItem,
            this.logisticaDeEntregaToolStripMenuItem});
            this.menuStrip1.Location = new System.Drawing.Point(0, 0);
            this.menuStrip1.Name = "menuStrip1";
            this.menuStrip1.Size = new System.Drawing.Size(1361, 28);
            this.menuStrip1.TabIndex = 0;
            this.menuStrip1.Text = "menuStrip1";
            // 
            // consultaDeCToolStripMenuItem
            // 
            this.consultaDeCToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.catalogoDeProductosToolStripMenuItem});
            this.consultaDeCToolStripMenuItem.Name = "consultaDeCToolStripMenuItem";
            this.consultaDeCToolStripMenuItem.Size = new System.Drawing.Size(252, 24);
            this.consultaDeCToolStripMenuItem.Text = "Consulta de catálogos de compras";
            // 
            // catalogoDeProductosToolStripMenuItem
            // 
            this.catalogoDeProductosToolStripMenuItem.Name = "catalogoDeProductosToolStripMenuItem";
            this.catalogoDeProductosToolStripMenuItem.Size = new System.Drawing.Size(245, 26);
            this.catalogoDeProductosToolStripMenuItem.Text = "Catalogo de productos";
            this.catalogoDeProductosToolStripMenuItem.Click += new System.EventHandler(this.catalogoDeProductosToolStripMenuItem_Click_1);
            // 
            // gestiónDeComprasToolStripMenuItem
            // 
            this.gestiónDeComprasToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.pToolStripMenuItem,
            this.ordenDeCompraGeneradaToolStripMenuItem});
            this.gestiónDeComprasToolStripMenuItem.Name = "gestiónDeComprasToolStripMenuItem";
            this.gestiónDeComprasToolStripMenuItem.Size = new System.Drawing.Size(155, 24);
            this.gestiónDeComprasToolStripMenuItem.Text = "Gestión de compras";
            // 
            // pToolStripMenuItem
            // 
            this.pToolStripMenuItem.Name = "pToolStripMenuItem";
            this.pToolStripMenuItem.Size = new System.Drawing.Size(276, 26);
            this.pToolStripMenuItem.Text = "Método de pago";
            this.pToolStripMenuItem.Click += new System.EventHandler(this.pToolStripMenuItem_Click);
            // 
            // ordenDeCompraGeneradaToolStripMenuItem
            // 
            this.ordenDeCompraGeneradaToolStripMenuItem.Name = "ordenDeCompraGeneradaToolStripMenuItem";
            this.ordenDeCompraGeneradaToolStripMenuItem.Size = new System.Drawing.Size(276, 26);
            this.ordenDeCompraGeneradaToolStripMenuItem.Text = "Orden de compra generada";
            this.ordenDeCompraGeneradaToolStripMenuItem.Click += new System.EventHandler(this.ordenDeCompraGeneradaToolStripMenuItem_Click);
            // 
            // labelNombreYApellido
            // 
            this.labelNombreYApellido.AutoSize = true;
            this.labelNombreYApellido.BackColor = System.Drawing.SystemColors.Window;
            this.labelNombreYApellido.Font = new System.Drawing.Font("Segoe UI", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelNombreYApellido.Location = new System.Drawing.Point(1168, 62);
            this.labelNombreYApellido.Name = "labelNombreYApellido";
            this.labelNombreYApellido.Size = new System.Drawing.Size(79, 31);
            this.labelNombreYApellido.TabIndex = 2;
            this.labelNombreYApellido.Text = "label1";
            this.labelNombreYApellido.Visible = false;
            // 
            // logisticaDeEntregaToolStripMenuItem
            // 
            this.logisticaDeEntregaToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.enviosToolStripMenuItem});
            this.logisticaDeEntregaToolStripMenuItem.Name = "logisticaDeEntregaToolStripMenuItem";
            this.logisticaDeEntregaToolStripMenuItem.Size = new System.Drawing.Size(158, 24);
            this.logisticaDeEntregaToolStripMenuItem.Text = "Logística de entrega";
            // 
            // enviosToolStripMenuItem
            // 
            this.enviosToolStripMenuItem.Name = "enviosToolStripMenuItem";
            this.enviosToolStripMenuItem.Size = new System.Drawing.Size(224, 26);
            this.enviosToolStripMenuItem.Text = "Envios";
            this.enviosToolStripMenuItem.Click += new System.EventHandler(this.enviosToolStripMenuItem_Click);
            // 
            // FrmModulos
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.ClientSize = new System.Drawing.Size(1361, 684);
            this.Controls.Add(this.labelNombreYApellido);
            this.Controls.Add(this.menuStrip1);
            this.IsMdiContainer = true;
            this.MainMenuStrip = this.menuStrip1;
            this.Name = "FrmModulos";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Bienvenid@ a Teleshopping";
            this.menuStrip1.ResumeLayout(false);
            this.menuStrip1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.MenuStrip menuStrip1;
        private System.Windows.Forms.ToolStripMenuItem consultaDeCToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem gestiónDeComprasToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem catalogoDeProductosToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem pToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem ordenDeCompraGeneradaToolStripMenuItem;
        public System.Windows.Forms.Label labelNombreYApellido;
        private System.Windows.Forms.ToolStripMenuItem logisticaDeEntregaToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem enviosToolStripMenuItem;
    }
}