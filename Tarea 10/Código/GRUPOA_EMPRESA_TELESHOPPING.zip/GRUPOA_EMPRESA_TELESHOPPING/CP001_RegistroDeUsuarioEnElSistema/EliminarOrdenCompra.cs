﻿using CapaNegocio;
using NUnit.Framework;
using System;
using System.Data;

namespace Pruebas
{
    [TestFixture]
    public class EliminarOrdenCompra
    {
        private OrdenDePagoN ordenDePagoNegocio;

        [OneTimeSetUp]
        public void OneTimeSetUp()
        {
            ordenDePagoNegocio = new OrdenDePagoN();
        }

        [Test]
        public void EliminarOrdenPagoPorFecha()
        {
            // Obtener la fecha y hora de la orden de pago que deseas eliminar 
            DateTime fechaHora = DateTime.Parse("2023-11-05 16:24:02.120");

            // Intenta eliminar la orden de pago
            bool eliminacionExitosa = ordenDePagoNegocio.EliminarRegistro(fechaHora);

            // Verificar si la eliminación fue exitosa
            Assert.IsTrue(eliminacionExitosa, "La orden de pago no se eliminó correctamente.");
        }
    }
}
