﻿using NUnit.Framework;
using CapaDatos; 

namespace TusPruebas
{
    [TestFixture]
    public class EliminarUsuarioSistema
    {
        [Test]
        public void EliminarUsuario_DatosValidos_UsuarioEliminado()
        {
            // Arrange (Preparación)
            // Establecemos las condiciones iniciales y objetos necesarios para la prueba.
            string ciToDelete = "0950722823"; // CI del usuario a eliminar
            UsuarioDatos usuarioDatos = new UsuarioDatos("Data Source=HECTOR;Initial Catalog=GrupoATeleshopping;Integrated Security=True");
            // Creamos una instancia de la clase UsuarioDatos con la cadena de conexión.

            // Act (Acción)
            // Realizamos la acción que queremos probar.
            bool eliminacionExitosa = usuarioDatos.EliminarUsuarioPorCI(ciToDelete);
            // Llamamos al método EliminarUsuarioPorCI con el CI proporcionado.

            // Assert (Comprobación)
            // Verificamos si la acción produjo el resultado esperado.
            Assert.IsTrue(eliminacionExitosa);
            // Verificamos si la eliminación fue exitosa (esperamos true).

        }
    }
}
