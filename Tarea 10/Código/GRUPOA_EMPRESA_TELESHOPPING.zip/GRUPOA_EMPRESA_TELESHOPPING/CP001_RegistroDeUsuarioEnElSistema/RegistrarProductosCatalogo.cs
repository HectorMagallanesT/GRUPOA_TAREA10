﻿using CapaNegocio;
using System;
using System.Collections.Generic;
using System.Data;
using System.IO;
using NUnit.Framework;

namespace Pruebas
{
    [TestFixture]
    public class RegistrarProductosCatalogo
    {
        [Test]
        public void InsertarProductoExitoso()
        {
            CN_Productos productos = new CN_Productos();

            byte[] foto;
            string nombre = "medias";
            string descripcion = "color blancas, seda 100%";
            decimal precio = 2.0m;

            // Cargar la imagen desde un archivo
            string rutaDeLaImagen = @"C:\Users\hmaga\Downloads\Medias.jpg";
            using (FileStream stream = new FileStream(rutaDeLaImagen, FileMode.Open, FileAccess.Read))
            {
                using (BinaryReader reader = new BinaryReader(stream))
                {
                    foto = reader.ReadBytes((int)stream.Length);
                }
            }

            bool insercionExitosa = productos.InsertarProducto(foto, nombre, descripcion, precio);

            Assert.IsTrue(insercionExitosa, "La inserción de producto debería ser exitosa.");
        }

        [Test]
        public void BuscarProductosPorNombreExitoso()
        {
            CN_Productos productos = new CN_Productos();

            string nombreProducto = "medias";

            DataTable resultado = productos.BuscarProductosPorNombre(nombreProducto);

            Assert.IsNotNull(resultado, "La búsqueda de productos debería ser exitosa.");
        }

        [Test]
        public void GetListaProductosExitoso()
        {
            CN_Productos productos = new CN_Productos();

            DataTable listaProductos = productos.GetListaProductos();

            Assert.IsNotNull(listaProductos, "Obtener la lista de productos debería ser exitoso.");
        }
    }
}
